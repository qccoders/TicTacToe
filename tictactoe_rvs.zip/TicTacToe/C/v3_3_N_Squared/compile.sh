#!/bin/sh
#
# Compile and enforce ANSI Standard C90 Coding
# // Comments not allowed. New variable instantiation only allowed before executable
# statements,  malloc for dynamic memory allocation, strings don't exist - only
# character arrays,...
#
# This script is for compiling on Linux
# Other options are -D_Win or -D_Unix
#
rm -f ./tictactoe_v3_3_N_Squared
gcc -std=c90 -Wpedantic -Wall -pedantic-errors -D_Linux -o ./tictactoe_v3_3_N_Squared ./tictactoe_v3_3_N_Squared.c
