/*
        Tic Tac Whoa in ANSI Standard C90 written by R.V. Shannon Jr., 2019

        This game is a variation on Tic Tac Toe allowing between 3 and 25
        rows and columns

        developed from the C++ written by the same author so that
        comparisons can be made between C++ and Standard C90
        (We've come a long way!!!)

        This code uses dynamic memory allocation to allow any number
        of rows and columns in "Tic Tac Whoa" from 3 to 25 using malloc

*/

/* stdio.h is needed to use printf and getchar for reading and writing            */
#include <stdio.h>
/*  stdlib.h is needed for dynamic memory allocation (ie., use of malloc)         */
#include <stdlib.h>
/*  string.h below is needed to use strcpy and strncpy used to record moves       */
/*  by changing elements of char **Board = char *Board[i] = Board[i][j]           */
#include <string.h>
#include <time.h>
/*
     Declare global variables
*/
 int Length=0;
 int Length_Squared=0;


int main()
{

/*                  Declare local and passed variables                        */
 char **Board;      /* A doubly subscripted dynamically allocated char array  */
                    /* used to store all the elements of the TicTacWhoa Board */
/* Player 1's name stored in a statically allocated char array                */
 char Player_1_Name[80];
/* Player 2's name stored in a statically allocated char array                */
 char Player_2_Name[80];
/* Whose_Turn=1 means it's player 1's turn, =2 means it's player 2's turn     */
 int Whose_Turn = 1;
/* Move is the Board location where the player wants to move                  */ 
 int Move;
 int i,j;
 int winner;
/* Total_Moves is the total number of moves made so far in the current game   */
 int Total_Moves = 0;
/*
*/
 unsigned char tmpchar;
 unsigned char EntryLine[81];

/*
   Function Prototypes
*/
 void showBoard(int, char **);
 int moveIsValid(int, int, char **);
/* whoWon Returns 0 if no one has won, 1 if player 1 has won,
   and 2 if player 2 has won                                                  */ 
 int whoWon(char **);


/*
   Initialization of Variables
*/
 EntryLine[0]=' ';
 winner=0;

 while(Length < 3 || Length > 25)
 {
/* Get the Number of Rows (= the Number of Columns) in the Tic Tac Toe Game   */
    printf( "Please enter the number of Rows (= the Number of Columns) for the game: ");
    scanf("%d",&Length);
    printf("\n");
    if (Length < 3)
    {
       printf("You must have at least 3 rows and 3 columns!!\n"); 
    }
    if (Length > 25)
    {
       printf("At most 25 rows and 25 columns are allowed!!\n"); 
    }
 }

 Length_Squared=Length*Length;
 Board = (char **) malloc(sizeof(char *)*Length_Squared);
 for(i=0 ; i<Length_Squared ; i++)
 {
    /* 3 is the length of each string element                             */
    Board[i] = (char *) malloc(sizeof(char)*3);
 }


/*            Get the player names                                            */
    printf("Player 1, Please enter your name: ");
    scanf("%s",Player_1_Name);

    printf("\n");
    printf("Player 2, Computer Name: ");
    scanf("%s",Player_2_Name);
    printf("\n");

 do
 {
    /* Seed the random number generator.                                      */
    srand(time(NULL));

    /* 1 means it's player 1's turn, 2 means it's player 2's turn             */
    /* This could also be made random                                         */
    Whose_Turn = 1;
    Total_Moves = 0;

    /* Clear the screen for a new game                                        */
#ifdef _Win
    system("cls");
#elif _Linux || _Unix
    system("clear");
#endif

/*
       Assign/reassign the initial values (" 1 " through "Length_Squared")
       to the playing board array elements
*/

    for(i=0 ; i<Length_Squared ; i++)
    {
       if(i<9)
       {
          sprintf(Board[i], " %d ", i+1);
       }
       else if(i>98)
       {
          sprintf(Board[i], "%d", i+1);
       }
       else      /* 9 < i+1 < 100                                             */
       {
          sprintf(Board[i], " %d", i+1);
       }
    }
    /* Show the board                                                         */
    showBoard(Total_Moves,Board);

    /* Start a game                                                           */
    while ((whoWon(Board)) == 0 && Total_Moves < Length_Squared)
    {
	/* Do this until a valid move is chosen                               */
	do
        {
	    if (Whose_Turn == 1)
            {
		/* Show the board                                             */
                if(Total_Moves > 0) showBoard(Total_Moves,Board);

		printf("%s: It's your turn.\n",Player_1_Name);
		/* Get the move                                               */
		printf("Enter the number of the spot where you'd like to move: ");
                scanf(" %d",&Move);
                tmpchar=getchar();

	    }
            else
            {
		/* Computer selects a random board location to move to        */
		Move = rand()%Length_Squared + 1;
	    }

	} while (moveIsValid(Move-1,Whose_Turn,Board) == 0);

	/* Add 1 to Total_Moves                                               */
	Total_Moves++;

	/* Change whose turn it is                                            */
	switch (Whose_Turn)
        {
           case (1):
	      /* No need for braces in the cases, unless you define           */
	      /* a local variable with a constructor.                         */
	      strncpy(Board[Move-1]," X ",3);
	      Whose_Turn = 2;
	      break;
	   case (2):
              strncpy(Board[Move-1]," O ",3);
              Whose_Turn = 1;
	}
    }

    /* Show the board                                                         */
    showBoard(Total_Moves,Board);

/*
       A switch statement is most appropriate here because whoWon need
       only be called once and since we are checking the value of a single
       expression
*/
    switch (winner=whoWon(Board))
    {
      case 1:
	printf("%s has won the game!\n",Player_1_Name);
	break;
      case 2:
	printf("%s has won the game!\n",Player_2_Name);
	break;
      default:
	printf("It's a tie game!\n");
	break;
    }
    printf("Play another game? (or Enter x to Exit): ");

/*
    Read User entered characters until a newline is found or
    80 chars have been read
*/
    tmpchar=' ';
    j=0;
    while((tmpchar=getchar()) != '\n' && j<81)
    {
       EntryLine[j]=tmpchar;
#ifdef _DEBUG1
       printf("j=%d        EntryLine[j]='%c'\n",j,EntryLine[j]);
#endif
       j++;
    }
    EntryLine[j]='\0';

 } while (EntryLine[j-1] != 'x' && EntryLine[j-1] != 'X');

/*
    system("PAUSE");
*/
    system("sleep 1");

/*
     Now delete the memory that was dynamically allocated for the
     doubly subscripted array Board[i][j]
*/

 for(i=0 ; i<Length_Squared ; i++)
 {
    free(Board[i]);
 }
 free(Board);

 return 0;
}

void showBoard(int Move_Number, char **Board)
{
 int i,j;
/*      Clear the screen prior to a board redraw if moves have been made      */
 if(Move_Number > 0) 
 {
    system("sleep 1");
#ifdef _Win
            system("cls");
#elif _Linux || _Unix
            system("clear");
#endif
 }

 printf("\n");
/*
   Write the first Length-1 rows within the j for loop
*/
 for (j=0 ; j<Length-1 ; j++)
 {
    for (i=(j*Length) ; i<((j+1)*Length)-1 ; i++)
    {
       printf("%s |",Board[i]);
    }
    printf("%s\n",Board[((j+1)*Length)-1]);
/*
   Write the underscores between the rows
*/
    for (i=(j*Length) ; i<((j+1)*Length)-1 ; i++)
    {
       printf("----+");
    }
    printf("----\n");
 }
/*
   Write the last row (j=Length-1)
*/
 for (i=(Length_Squared-Length) ; i<(Length_Squared-1) ; i++)
 {
    printf("%s |",Board[i]);
 }
 printf("%s",Board[Length_Squared-1]);
 printf("\n");
}

int moveIsValid(int m, int Whose_Turn, char **Board)
{
/*
    Determine if the move is valid and if it's Player 1's turn and it's not
    valid, give him a message
*/

    if(m >= 0 && m < Length_Squared && strcmp(Board[m]," X ")!=0 &&
                                       strcmp(Board[m]," O ")!=0)
    {
       return 1;
    }
    else if (Whose_Turn == 1)
    {
       /* Warn the Human Player of an Invalid Selection                       */
       printf("Invalid Selection. Pick again!!\n");
       return 0;
    }
    else
    {
       /* No need to Warn the Random Generator of an Invalid Selection        */
       return 0;
    }
}

int stringToWinner(char *Board_elem)
{

/*
    This stringtoWinner function is used by whoWon to return who won
    the game
*/

    if (strcmp(Board_elem," X ") == 0)
    {
	return 1;
    }
    else
    {
	return 2;
    }
}
    
int whoWon(char **Board)
{
 int i,j;
 int winning_row=0,winning_col=0;
 int different_values;
 char winner[3];
/*
   Compare row i elements for each column j
*/
 for(j=0 ; j<((Length-1)*Length)+1 ; j=j+Length)
 {
    winning_row++;
    different_values=0;
    strcpy(winner,&Board[j][0]);
    for(i=1+j ; i<Length+j ; i++)
    {
        if(strncmp(Board[i-1],Board[i],3) != 0) different_values++;
    }
    if(different_values == 0)
    {
       printf("Row %d is a winner!!!\n",winning_row);
       return stringToWinner(winner);
    }
 }
/*
   Compare each column element j for each column starting with element i
*/
 for(i=0 ; i<Length; i++)
 {
    winning_col++;
    different_values=0;
    strcpy(winner,&Board[i][0]);
    for(j=i+Length ; j<((Length-1)*Length)+i+1 ; j=j+Length)
    {
        if(strncmp(Board[j-Length],Board[j],3) != 0) different_values++;
    }
    if(different_values == 0)
    {
       printf("Column %d is a winner!!!\n",winning_col);
       return stringToWinner(winner);
    }
 }
/*
   Check diagonal from the Upper Right to the Lower Left
*/
    different_values=0;
    strcpy(winner,&Board[Length-1][0]);
    for(j=2*Length-2 ; j<((Length-1)*Length)+1 ; j=j+Length-1)
    {
        if(strncmp(Board[j-Length+1],Board[j],3) != 0) different_values++;
    }
    if(different_values == 0)
    {
       printf("The diagonal from the lower left to the upper right is a winner!!!\n");
       return stringToWinner(winner);
    }
/*
   Check diagonal from the Upper Left to the Lower Right
*/
    different_values=0;
    strcpy(winner,&Board[0][0]);
    for(j=Length+1 ; j<Length_Squared ; j=j+Length+1)
    {
        if(strncmp(Board[j-Length-1],Board[j],3) != 0) different_values++;
    }
    if(different_values == 0)
    {
       printf("The diagonal from the upper left to the lower right is a winner!!!\n");
       return stringToWinner(winner);
    }

    return 0;
}
