#!/bin/sh
#
rm -f ./tictactoe_v1_4.exe
gfortran -std=f2008 -c ./board_data.f08
gfortran -std=f2008 -c ./tictactoe_v1_4.f08
gfortran -std=f2008 -o ./tictactoe_v1_4.exe ./tictactoe_v1_4.o board_data.o
rm -f ./*.o
