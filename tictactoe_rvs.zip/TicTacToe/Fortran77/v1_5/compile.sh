#!/bin/sh
#
rm -f ./tictactoe_v1_5.exe
# gfortran -std=legacy -lV77 -o ./tictactoe_v1_5.exe ./tictactoe_v1_5.f
gfortran -std=legacy -o ./tictactoe_v1_5.exe ./tictactoe_v1_5.f
