#!/bin/sh
#
# Compile and enforce ANSI Standard C++ 2011 Coding
#
# This script is for compiling on Linux
# Other options are -D_Win or -D_Unix
#
rm -f ./tictactoe_v2_7_N_Squared
g++ -std=c++11 -Wpedantic -Wall -pedantic-errors -D_Linux -o ./tictactoe_v2_7_N_Squared ./tictactoe_v2_7_N_Squared.cpp
