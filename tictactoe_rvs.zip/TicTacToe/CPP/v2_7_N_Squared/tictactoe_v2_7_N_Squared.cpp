// Tic Tac Toe, by Sun A
// Modifications made by R.V.S Jr.:
//    Renumbered selectable Board Locations to be from 1-Length_Squared-1
//
//    Updated code to modern C++ which requires main return an int to the system
//
//    Changed markers to capital X and O instead of x and o
//
//    Added Total_Moves being passed to showBoard to know if the screen should be
//    cleared and redrawn or just drawn.
//
//    Added ability to start a new game or end after a game ends
//
//    Added N Squared Tic Tac Toe Capability

// Include the libraries
#include <iostream>
#include <string>
#include <cstring>
#include <ctime>

//Use the standard namespace
using namespace std;

// Declare global variables
// char *Board;
string *Board;
int Length=0;
int Length_Squared=0;
char Entry=' ';

// Declare functions
void showBoard(int Move_Number);
bool moveIsValid(int m, int Players_Turn);
int whoWon(); //Returns 0 if no one has won, 1 if player 1 has won,
	      //and 2 if player 2 has won 

int main()
{

    // Declare local variables
    string Player_1_Name;
    string Player_2_Name;
    int Whose_Turn = 1;		// 1 means it's player 1's turn, 2 means it's player 2's turn
    int Move;			// Stores where the player wants to move
    int Total_Moves = 0;

 while(Length < 3 || Length > 25)
 {
    // Get the Number of Rows (= the Number of Columns) in the Tic Tac Toe Game
    cout << "Please enter the number of Rows (= the Number of Columns) for the game: ";
    cin >> Length;
    cout << endl;
    if (Length < 3)
    {
       cout << "You must have at least 3 rows and 3 columns!!" << endl; 
    }
    if (Length > 25)
    {
       cout << "At most 25 rows and 25 columns are allowed!!" << endl; 
    }
 }

 Length_Squared=Length*Length;
 Board = new string [Length_Squared];

    // Get player names
    cout << "Player 1, Please enter your name: ";
    cin >> Player_1_Name;

    // dmh - do you mean for the computer to have a name?
    cout << endl;
    cout << "Player 2, Computer Name: ";
    cin >> Player_2_Name;
    cout << endl;

 do
 {
    // Seed the random number generator.
    srand(time(NULL));
    // 1 means it's player 1's turn, 2 means it's player 2's turn
    // This could also be made random
    Whose_Turn = 1;
    Total_Moves = 0;
//  Clear the screen for a new game
    system("clear");
    //
    // Assign/reassign the initial values ('1' through '9') to the 
    // playing board locations
    //

    for(int i=0 ; i<Length_Squared ; i++)
    {
        Board[i].clear();
        Board[i]=to_string(i+1);
        if(i<9)
        {
           Board[i].insert(static_cast<size_t> (0)," ");
           Board[i].insert(static_cast<size_t> (2)," ");
        }
        if(i>8 && i<100)
        {
           Board[i].insert(static_cast<size_t> (0)," ");
        }
    }
    // Show the board
    showBoard(Total_Moves);
    // 
    // Start a game
    while (whoWon() == 0 && Total_Moves < Length_Squared)
    {
	// Do this until the player chooses a valid move
	do
        {
	    if (Whose_Turn == 1)
            {
		// Show the board
                if(Total_Moves > 0) showBoard(Total_Moves);

		cout << Player_1_Name << ": It's your turn." << endl;
		// Get the move
		cout << "Enter the number of the spot where you'd like to move." << endl;
		cin >> Move;

	    }
            else
            {
		// Computer selects random square
		Move = rand()%Length_Squared + 1;
	    }

	} while (moveIsValid(Move-1,Whose_Turn) != true);

	// Add 1 to Total_Moves
	Total_Moves++;

	// Change whose turn it is
	switch (Whose_Turn)
        {
           case (1):
	      // dmh - No need for braces in the cases, unless you define
	      // a local variable with a constructor.
	      Board[Move-1] = " X ";
	      Whose_Turn = 2;
	      break;
	   case (2):
              Board[Move-1] = " O ";
              Whose_Turn = 1;
	}
    }

    // Show the board
    showBoard(Total_Moves);

    // dmh - I changed this to a switch statement so (1) whoWon()
    // would be called only once and (2) because switch is more
    // appropriate since you're checking the value of a single
    // expression
    switch (whoWon())
    {
      case 1:
	cout << Player_1_Name << " has won the game!" << endl;
	break;
      case 2:
	cout << Player_2_Name << " has won the game!" << endl;
	break;
      default:
	cout << "It's a tie game!" << endl;
	break;
    }
    cout << "Play another game? (or Enter x to Exit): ";
    cin >> Entry;
 } while (Entry != 'x' && Entry != 'X');

//    system("PAUSE");
    system("sleep 3");

    delete[] Board;
    return 0;
}

void showBoard(int Move_Number)
{
 int i,j;
//
 if(Move_Number > 0) system("clear");
 cout << endl;
//
// Write the first Length-1 rows within the j for loop
//
 for (j=0 ; j<Length-1 ; j++)
 {
    for (i=(j*Length) ; i<((j+1)*Length)-1 ; i++)
    {
       cout << Board[i] << " |";
    }
    cout << Board[((j+1)*Length)-1] << endl;
//
// Write the underscores between the rows
//
    for (i=(j*Length) ; i<((j+1)*Length)-1 ; i++)
    {
       cout << "----+";
    }
    cout << "----" << endl;
 }
//
// Write the last row (j=Length-1)
//
 for (i=(Length_Squared-Length) ; i<(Length_Squared-1) ; i++)
 {
    cout << Board[i] << " |";
 }
 cout << Board[Length_Squared-1] << endl;
 cout << endl;
}

bool moveIsValid(int m, int Whose_Turn)
{
    // dmh - There's no need for an "if" statement here. Just return
    // the value of the boolean expression
    if(m >= 0 && m < Length_Squared && Board[m] != " X " && Board[m] != " O ")
    {
       return true;
    }
    else if (Whose_Turn == 1)
    {
       // Warn the Human Player of an Invalid Selection
       cout << "Invalid Selection. Pick again!!" << endl;
       return false;
    }
    else
    {
       // No need to Warn the Random Generator of an Invalid Selection
       return false;
    }
}

// dmh - here's a helper function that shows one way to reduce the
// duplicate code in whoWon().
int stringToWinner(string str)
{
    if (str == " X ")
    {
	return 1;
    }
    else
    {
	return 2;
    }
}
    
int whoWon()
{
 int i,j;
 int winning_row=0,winning_col=0;
 int different_values;
 string winner;
//
// Compare row i elements for each column j
//
 for(j=0 ; j<((Length-1)*Length)+1 ; j=j+Length)
 {
    winning_row++;
    different_values=0;
    winner=Board[j];
    for(i=1+j ; i<Length+j ; i++)
    {
        if(Board[i-1] != Board[i]) different_values++;
    }
    if(different_values == 0)
    {
       cout << "Row " << winning_row << " is a winner!!!" << endl;
       return stringToWinner(winner);
    }
 }
//
// Compare each column element j for each column starting with element i
//
 for(i=0 ; i<Length; i++)
 {
    winning_col++;
    different_values=0;
    winner=Board[i];
    for(j=i+Length ; j<((Length-1)*Length)+i+1 ; j=j+Length)
    {
        if(Board[j-Length] != Board[j]) different_values++;
    }
    if(different_values == 0)
    {
       cout << "Column " << winning_col << " is a winner!!!" << endl;
       return stringToWinner(winner);
    }
 }
//
// Check diagonal from the Upper Right to the Lower Left
//
    different_values=0;
    winner=Board[Length-1];
    for(j=2*Length-2 ; j<((Length-1)*Length)+1 ; j=j+Length-1)
    {
        if(Board[j-Length+1] != Board[j]) different_values++;
    }
    if(different_values == 0)
    {
       cout << "The diagonal from the lower left to the upper right is a winner!!!" << endl;
       return stringToWinner(winner);
    }
//
// Check diagonal from the Upper Left to the Lower Right
//
    different_values=0;
    winner=Board[0];
    for(j=Length+1 ; j<Length_Squared ; j=j+Length+1)
    {
        if(Board[j-Length-1] != Board[j]) different_values++;
    }
    if(different_values == 0)
    {
       cout << "The diagonal from the upper left to the lower right is a winner!!!" << endl;
       return stringToWinner(winner);
    }

    return 0;
}
